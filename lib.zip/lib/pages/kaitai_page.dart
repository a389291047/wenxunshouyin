import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import '../models/login_model.dart';
import 'din_can_page.dart';

// 桌台模型（修正状态样式+过滤无效状态）
class ZhuotaiModel {
  final int id;
  final String name;
  final String? quyu;
  final String renshu;
  final int wenxunId;
  final String status; // 仅保留：0-空闲 1-已预定 2-就餐中 3-扫码点餐
  final String title;

  ZhuotaiModel({
    required this.id,
    required this.name,
    this.quyu,
    required this.renshu,
    required this.wenxunId,
    required this.status,
    required this.title,
  });

  factory ZhuotaiModel.fromJson(Map<String, dynamic> json) {
    final dynamic statusValue = json['status'] ?? 0;
    final String status = statusValue is int ? statusValue.toString() : (statusValue as String? ?? '0');

    // 过滤无效状态，仅保留0/1/2/3
    final validStatus = ['0', '1', '2', '3'].contains(status) ? status : '0';

    return ZhuotaiModel(
      id: json['id'] is int ? json['id'] : 0,
      name: json['name'] is String ? json['name'] : '',
      quyu: json['quyu'] is String ? json['quyu'] : null,
      renshu: json['renshu'] is String ? json['renshu'] : '',
      wenxunId: json['wenxun_id'] is int ? json['wenxun_id'] : 0,
      status: validStatus,
      title: json['title'] is String ? json['title'] : '',
    );
  }

  // 复制模型（用于更新状态）
  ZhuotaiModel copyWith({
    int? id,
    String? name,
    String? quyu,
    String? renshu,
    int? wenxunId,
    String? status,
    String? title,
  }) {
    return ZhuotaiModel(
      id: id ?? this.id,
      name: name ?? this.name,
      quyu: quyu ?? this.quyu,
      renshu: renshu ?? this.renshu,
      wenxunId: wenxunId ?? this.wenxunId,
      status: status ?? this.status,
      title: title ?? this.title,
    );
  }

  // 桌台卡片背景色（修正：空闲-白 预定/扫码点餐-绿 就餐中-红）
  Color get cardBgColor {
    switch (status) {
      case '1': // 已预定
      case '3': // 扫码点餐（原8改为3）
        return Colors.green.shade500;
      case '2': // 就餐中
        return Colors.red.shade500;
      default: // 0-空闲
        return Colors.white;
    }
  }

  // 桌台卡片文字颜色（修正：空闲-黑 其他-白）
  Color get cardTextColor {
    switch (status) {
      case '0': // 空闲
        return Colors.black87;
      default: // 预定/就餐中/扫码点餐
        return Colors.white;
    }
  }

  // 状态文字颜色
  Color get statusTextColor => cardTextColor;

  // 桌台卡片边框颜色
  Color get cardBorderColor {
    switch (status) {
      case '1':
      case '3':
        return Colors.green.shade200;
      case '2':
        return Colors.red.shade200;
      default:
        return Colors.grey.shade200;
    }
  }
}

class KaiTaiPage extends StatefulWidget {
  const KaiTaiPage({super.key});

  @override
  State<KaiTaiPage> createState() => _KaiTaiPageState();
}

class _KaiTaiPageState extends State<KaiTaiPage> {
  final UserInfoManager _userManager = UserInfoManager();
  final String _zhuotaiApiUrl = 'https://shop.wx-zf.com/shouyin/zhuotai';
  final String _kaitaiApiUrl = 'https://shop.wx-zf.com/shouyin/zhuotai/kaitai';
  final String _sseUrl = 'https://shop.wx-zf.com/shouyin/zhuotai/sseConnect';
  final String _updateStatusUrl = 'https://shop.wx-zf.com/shouyin/zhuotai/updateStatus';
  // 新增：取消订单接口地址
  final String _cancelOrderUrl = 'https://shop.wx-zf.com/shouyin/zhuotai/cancelOrder';

  int? _currentWenxunId;
  Map<String, List<ZhuotaiModel>> _quyuZhuotaiMap = {};
  List<String> _quyuList = [];
  String _selectedQuyu = '全部';
  bool _isLoading = true;
  String? _errorMessage;

  // SSE 相关
  StreamController<Map<String, dynamic>>? _sseController;
  Timer? _sseReconnectTimer;
  Timer? _debounceTimer;

  // 样式常量
  final Color _selectedTextColor = Colors.red;
  final Color _unselectedTextColor = Colors.black;
  final Color _unselectedBgColor = Colors.white;
  final Color _cardShadowColor = Colors.grey.withOpacity(0.2);
  final Color _grey500 = Colors.grey.shade500;
  final BorderRadius _borderRadius12 = BorderRadius.circular(12);

  @override
  void initState() {
    super.initState();
    _fetchZhuotaiList();
    _initSSE();
  }

  @override
  void dispose() {
    _sseController?.close();
    _sseReconnectTimer?.cancel();
    _debounceTimer?.cancel();
    super.dispose();
  }

  /// 初始化 SSE 连接
  void _initSSE() async {
    final wenxunId = await _userManager.getWenxunId();
    if (wenxunId == null || wenxunId.isEmpty) return;

    _sseController = StreamController.broadcast();
    _connectSSE(wenxunId);

    _sseController?.stream.listen((event) {
      if (event['type'] == 'zhuotai_update') {
        _handleZhuotaiUpdate(event['data']);
      }
    });
  }

  /// 建立 SSE 连接
  void _connectSSE(String wenxunId) async {
    try {
      final url = Uri.parse('$_sseUrl?wx_id=$wenxunId');
      final request = http.Request('GET', url);
      request.headers['Accept'] = 'text/event-stream';
      final response = await request.send();

      await for (var chunk in response.stream.transform(utf8.decoder)) {
        _parseSSEChunk(chunk);
      }
    } catch (e) {
      print('SSE 连接异常: $e');
      _reconnectSSE();
    }
  }

  /// 解析 SSE 数据块
  void _parseSSEChunk(String chunk) {
    final lines = chunk.split('\n');
    String? eventType;
    String? data;

    for (var line in lines) {
      line = line.trim();
      if (line.isEmpty) continue;

      if (line.startsWith('event: ')) {
        eventType = line.replaceFirst('event: ', '');
      } else if (line.startsWith('data: ')) {
        data = line.replaceFirst('data: ', '');
      }
    }

    if (eventType != null && data != null && data.isNotEmpty) {
      if (eventType == 'ping') {
        return;
      } else if (eventType == 'zhuotai_update') {
        _sseController?.add({
          'type': 'zhuotai_update',
          'data': json.decode(data)
        });
      }
    }
  }

  /// SSE 断线重连
  void _reconnectSSE() {
    _sseReconnectTimer?.cancel();
    _sseReconnectTimer = Timer(const Duration(seconds: 3), () async {
      final wenxunId = await _userManager.getWenxunId();
      if (wenxunId != null) {
        _connectSSE(wenxunId);
      }
    });
  }

  /// 处理桌台状态更新
  void _handleZhuotaiUpdate(dynamic updateData) {
    if (updateData['code'] != 200 || updateData['updated_list'].isEmpty) return;

    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(seconds: 1), () {
      setState(() {
        List<dynamic> updatedList = updateData['updated_list'];
        for (var item in updatedList) {
          ZhuotaiModel updatedZhuotai = ZhuotaiModel.fromJson(item);
          _quyuZhuotaiMap.forEach((quyu, list) {
            for (int i = 0; i < list.length; i++) {
              if (list[i].id == updatedZhuotai.id) {
                _quyuZhuotaiMap[quyu]![i] = updatedZhuotai;
                break;
              }
            }
          });
        }
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('桌台状态已更新'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );
    });
  }

  /// 获取桌台列表
  Future<void> _fetchZhuotaiList() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final wenxunIdStr = await _userManager.getWenxunId();
      if (wenxunIdStr == null || wenxunIdStr.isEmpty) {
        setState(() {
          _errorMessage = '未获取到商户信息，请重新登录';
          _isLoading = false;
        });
        return;
      }

      _currentWenxunId = int.tryParse(wenxunIdStr);
      if (_currentWenxunId == null) {
        setState(() {
          _errorMessage = '商户ID格式错误，请重新登录';
          _isLoading = false;
        });
        return;
      }

      final response = await http.post(
        Uri.parse(_zhuotaiApiUrl),
        headers: const {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {'wenxun_id': _currentWenxunId.toString()},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['code'] == 200) {
          final List<dynamic> zhuotaiJsonList = data['canyin'] ?? [];
          final List<ZhuotaiModel> zhuotaiList = zhuotaiJsonList
              .map((json) => ZhuotaiModel.fromJson(json))
              .where((z) => z.wenxunId == _currentWenxunId)
              .toList();

          final Map<String, List<ZhuotaiModel>> groupMap = {};
          groupMap['全部'] = List.from(zhuotaiList);
          for (final z in zhuotaiList) {
            final quyu = z.quyu ?? '未分组';
            if (!groupMap.containsKey(quyu)) {
              groupMap[quyu] = [];
            }
            groupMap[quyu]!.add(z);
          }

          _quyuList = ['全部'] + groupMap.keys.where((key) => key != '全部').toList();

          setState(() {
            _quyuZhuotaiMap = groupMap;
            _isLoading = false;
          });
        } else {
          setState(() {
            _errorMessage = data['msg'] ?? '获取桌台列表失败';
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _errorMessage = '请求失败：状态码${response.statusCode}';
          _isLoading = false;
        });
      }
    } on TimeoutException {
      setState(() {
        _errorMessage = '请求超时，请检查网络';
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = '加载桌台失败：${e.toString()}';
        _isLoading = false;
      });
    }
  }

  /// 切换区域
  void _switchQuyu(String quyu) {
    setState(() {
      _selectedQuyu = quyu;
    });
  }

  /// 获取选中区域的桌台
  List<ZhuotaiModel> _getSelectedZhuotai() {
    return _quyuZhuotaiMap[_selectedQuyu] ?? [];
  }

  /// 处理桌台点击事件（扩展：支持取消订单）
  void _handleZhuotaiTap(ZhuotaiModel zhuotai) {
    switch (zhuotai.status) {
      case '0': // 空闲 → 显示操作菜单（点餐/设为预定）
        _showIdleOperationDialog(zhuotai);
        break;
      case '1': // 已预定 → 显示操作菜单（改空闲/点餐）
        _showBookedOperationDialog(zhuotai);
        break;
      case '2': // 就餐中 → 显示操作菜单（点餐/取消订单）
        _showDiningOperationDialog(zhuotai);
        break;
      case '3': // 扫码点餐 → 显示操作菜单（点餐/取消订单）
        _showScanOrderOperationDialog(zhuotai);
        break;
      default: // 其他状态 → 提示
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${zhuotai.title}桌当前状态：${_getStatusText(zhuotai.status)}，无法操作'),
            backgroundColor: Colors.grey.shade600,
            behavior: SnackBarBehavior.floating,
            elevation: 6,
          ),
        );
        break;
    }
  }

  /// 空闲桌台操作弹窗（点餐/设为预定）
  Future<void> _showIdleOperationDialog(ZhuotaiModel zhuotai) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${zhuotai.title} 操作选择'),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: _borderRadius12),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.restaurant, color: Colors.red),
              title: Text('立即点餐'),
              onTap: null,
            ),
            ListTile(
              leading: Icon(Icons.bookmark, color: Colors.green),
              title: Text('设为已预定'),
              onTap: null,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showKaitaiDialog(zhuotai); // 点餐弹窗
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('点餐'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _updateZhuotaiStatus(zhuotai, '1'); // 设为预定
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: const Text('设为预定'),
          ),
        ],
      ),
    );
  }

  /// 已预定桌台操作弹窗（改空闲/点餐）
  Future<void> _showBookedOperationDialog(ZhuotaiModel zhuotai) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${zhuotai.title} 操作选择'),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: _borderRadius12),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.restaurant, color: Colors.red),
              title: Text('立即点餐'),
              onTap: null,
            ),
            ListTile(
              leading: Icon(Icons.clear, color: Colors.grey),
              title: Text('改为空闲状态'),
              onTap: null,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _navigateToDianCanPage(zhuotai); // 直接点餐
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('点餐'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _updateZhuotaiStatus(zhuotai, '0'); // 改空闲
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
            child: const Text('改为空闲'),
          ),
        ],
      ),
    );
  }

  /// 就餐中桌台操作弹窗（点餐/取消订单）
  Future<void> _showDiningOperationDialog(ZhuotaiModel zhuotai) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${zhuotai.title} 操作选择'),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: _borderRadius12),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.restaurant, color: Colors.red),
              title: Text('继续点餐'),
              onTap: null,
            ),
            ListTile(
              leading: Icon(Icons.cancel, color: Colors.orange),
              title: Text('取消订单'),
              onTap: null,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _navigateToDianCanPage(zhuotai); // 继续点餐
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('点餐'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showCancelOrderDialog(zhuotai); // 取消订单
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            child: const Text('取消订单'),
          ),
        ],
      ),
    );
  }

  /// 扫码点餐桌台操作弹窗（点餐/取消订单）
  Future<void> _showScanOrderOperationDialog(ZhuotaiModel zhuotai) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${zhuotai.title} 操作选择'),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: _borderRadius12),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.restaurant, color: Colors.red),
              title: Text('继续点餐'),
              onTap: null,
            ),
            ListTile(
              leading: Icon(Icons.cancel, color: Colors.orange),
              title: Text('取消订单'),
              onTap: null,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _navigateToDianCanPage(zhuotai); // 继续点餐
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('点餐'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showCancelOrderDialog(zhuotai); // 取消订单
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            child: const Text('取消订单'),
          ),
        ],
      ),
    );
  }

  /// 显示取消订单确认弹窗
  void _showCancelOrderDialog(ZhuotaiModel zhuotai) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('取消${zhuotai.title}桌订单'),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: Text('确认取消${zhuotai.title}桌的订单并将桌台恢复为空闲状态？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _cancelOrder(zhuotai);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('确认取消'),
          ),
        ],
      ),
    );
  }

  /// 取消订单（桌台恢复空闲）核心方法
  Future<bool> _cancelOrder(ZhuotaiModel zhuotai) async {
    if (_currentWenxunId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('未获取到商户信息，无法取消订单'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return false;
    }

    setState(() => _isLoading = true);
    try {
      final response = await http.post(
        Uri.parse(_cancelOrderUrl),
        headers: const {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'wenxun_id': _currentWenxunId.toString(),
          'zhuotai_id': zhuotai.id.toString(),
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['code'] == 200) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${zhuotai.title}桌订单取消成功！'),
              backgroundColor: Colors.green.shade500,
              behavior: SnackBarBehavior.floating,
            ),
          );
          // 刷新桌台列表
          _fetchZhuotaiList();
          return true;
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['msg'] ?? '取消订单失败'),
              backgroundColor: Colors.red.shade500,
              behavior: SnackBarBehavior.floating,
            ),
          );
          return false;
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('请求失败：状态码${response.statusCode}'),
            backgroundColor: Colors.red.shade500,
            behavior: SnackBarBehavior.floating,
          ),
        );
        return false;
      }
    } on TimeoutException {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('取消订单请求超时，请重试'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return false;
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('取消订单失败：${e.toString()}'),
          backgroundColor: Colors.red.shade500,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return false;
    } finally {
      setState(() => _isLoading = false);
    }
  }

  /// 更新桌台状态（预定→空闲/空闲→预定）
  Future<void> _updateZhuotaiStatus(ZhuotaiModel zhuotai, String newStatus) async {
    setState(() => _isLoading = true);
    try {
      final response = await http.post(
        Uri.parse(_updateStatusUrl),
        headers: const {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'wenxun_id': _currentWenxunId.toString(),
          'zhuotai_id': zhuotai.id.toString(),
          'status': newStatus,
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['code'] == 200) {
          final statusText = newStatus == '0' ? '空闲' : '已预定';
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${zhuotai.title}桌已改为$statusText状态！'),
              backgroundColor: Colors.green.shade500,
              behavior: SnackBarBehavior.floating,
            ),
          );
          _fetchZhuotaiList(); // 刷新列表
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['msg'] ?? '状态更新失败'),
              backgroundColor: Colors.red.shade500,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('请求失败：${response.statusCode}'),
            backgroundColor: Colors.red.shade500,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } on TimeoutException {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('请求超时，请重试'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('操作失败：${e.toString()}'),
          backgroundColor: Colors.red.shade500,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  /// 跳转到点餐页面
  void _navigateToDianCanPage(ZhuotaiModel zhuotai) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DianCanPage(
          zhuotaiId: zhuotai.id,
          zhuotaiTitle: zhuotai.title,
          peopleCount: int.tryParse(zhuotai.renshu) ?? 0,
          wenxunId: _currentWenxunId!,
        ),
      ),
    );
  }

  /// 显示开台弹窗（空闲点餐时调用）
  Future<void> _showKaitaiDialog(ZhuotaiModel zhuotai) async {
    final TextEditingController _peopleController = TextEditingController(
      text: zhuotai.renshu.isNotEmpty ? zhuotai.renshu : '1',
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${zhuotai.title} 开台点餐'),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: _borderRadius12),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('该桌可容纳：${zhuotai.renshu.isNotEmpty ? zhuotai.renshu + '人' : '不限人数'}'),
            const SizedBox(height: 12),
            TextField(
              controller: _peopleController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: '实际就餐人数',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              onChanged: (value) {
                if (value.isEmpty) return;
                final numeric = int.tryParse(value);
                if (numeric == null || numeric < 1) {
                  _peopleController.text = '1';
                  _peopleController.selection = const TextSelection.collapsed(offset: 1);
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () async {
              final peopleCount = int.tryParse(_peopleController.text) ?? 1;
              Navigator.pop(context);
              final success = await _submitKaitai(zhuotai, peopleCount);
              if (success) {
                _navigateToDianCanPage(zhuotai);
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('确认开台'),
          ),
        ],
      ),
    );
  }

  /// 提交开台请求
  Future<bool> _submitKaitai(ZhuotaiModel zhuotai, int peopleCount) async {
    setState(() => _isLoading = true);
    try {
      final response = await http.post(
        Uri.parse(_kaitaiApiUrl),
        headers: const {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'wenxun_id': _currentWenxunId.toString(),
          'zhuotai_id': zhuotai.id.toString(),
          'people_count': peopleCount.toString(),
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['code'] == 200) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${zhuotai.title}桌开台成功！'),
              backgroundColor: Colors.green.shade500,
              behavior: SnackBarBehavior.floating,
            ),
          );
          _fetchZhuotaiList();
          return true;
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['msg'] ?? '开台失败'),
              backgroundColor: Colors.red.shade500,
              behavior: SnackBarBehavior.floating,
            ),
          );
          return false;
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('请求失败：${response.statusCode}'),
            backgroundColor: Colors.red.shade500,
            behavior: SnackBarBehavior.floating,
          ),
        );
        return false;
      }
    } on TimeoutException {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('开台请求超时'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return false;
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('开台失败：${e.toString()}'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return false;
    } finally {
      setState(() => _isLoading = false);
    }
  }

  /// 获取状态文字描述
  String _getStatusText(String status) {
    switch (status) {
      case '1':
        return '已预定';
      case '2':
        return '就餐中';
      case '3':
        return '扫码点餐';
      default:
        return '空闲';
    }
  }

  /// 构建区域按钮
  Widget _buildQuyuButton(String quyu) {
    final isSelected = _selectedQuyu == quyu;

    return TextButton(
      onPressed: () => _switchQuyu(quyu),
      style: TextButton.styleFrom(
        padding: EdgeInsets.zero,
        minimumSize: const Size(0, 0),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        backgroundColor: isSelected ? Colors.red.shade50 : Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
      child: Container(
        height: double.infinity * 0.8,
        alignment: Alignment.center,
        child: Text(
          quyu,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: isSelected ? _selectedTextColor : _unselectedTextColor,
            overflow: TextOverflow.ellipsis,
          ),
          maxLines: 1,
        ),
      ),
    );
  }

  /// 构建桌台卡片
  Widget _buildZhuotaiCard(ZhuotaiModel zhuotai) {
    return GestureDetector(
      onTap: () => _handleZhuotaiTap(zhuotai),
      child: Container(
        decoration: BoxDecoration(
          color: zhuotai.cardBgColor,
          borderRadius: _borderRadius12,
          border: Border.all(color: zhuotai.cardBorderColor),
          boxShadow: [
            BoxShadow(
              color: _cardShadowColor,
              blurRadius: 8,
              spreadRadius: 1,
              offset: const Offset(0, 3),
            )
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text(
              zhuotai.title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: zhuotai.cardTextColor,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              _getStatusText(zhuotai.status),
              style: TextStyle(
                fontSize: zhuotai.status == '0' ? 15 : 14,
                fontWeight: FontWeight.w600,
                color: zhuotai.statusTextColor,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              '${zhuotai.renshu.isNotEmpty && zhuotai.renshu != '0' ? zhuotai.renshu : '0'}人',
              style: TextStyle(
                fontSize: 12,
                color: zhuotai.cardTextColor,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selectedZhuotai = _getSelectedZhuotai();
    final screenHeight = MediaQuery.of(context).size.height;
    final availableHeight = screenHeight - 20;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Container(
          constraints: BoxConstraints(maxHeight: availableHeight),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: const BorderRadius.all(Radius.circular(20)),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.15),
                blurRadius: 12,
                spreadRadius: 0,
                offset: const Offset(0, 4),
              )
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              SizedBox(
                height: availableHeight * 0.1,
                child: ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                  child: Container(
                    color: _unselectedBgColor,
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: _isLoading
                        ? const Center(
                      child: CircularProgressIndicator(
                        color: Colors.red,
                        strokeWidth: 2,
                      ),
                    )
                        : _errorMessage != null
                        ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Text(
                          _errorMessage!,
                          style: const TextStyle(color: Colors.red, fontSize: 14),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                        : SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: _quyuList.map((quyu) {
                          final buttonWidth = screenWidth / _quyuList.length.clamp(2, 6);
                          return SizedBox(
                            width: buttonWidth,
                            child: _buildQuyuButton(quyu),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: Color(0xFFEEEEEE),
                        width: 0.8,
                      ),
                    ),
                  ),
                  child: _isLoading
                      ? const Center(
                    child: CircularProgressIndicator(
                      color: Colors.red,
                      strokeWidth: 2,
                    ),
                  )
                      : _errorMessage != null
                      ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text(
                        _errorMessage!,
                        style: const TextStyle(color: Colors.red, fontSize: 16),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                      : selectedZhuotai.isEmpty
                      ? Center(
                    child: Text(
                      '暂无桌台数据',
                      style: TextStyle(
                        fontSize: 17,
                        color: _grey500,
                      ),
                    ),
                  )
                      : Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                    child: GridView.builder(
                      shrinkWrap: true,
                      physics: const AlwaysScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: screenWidth > 600 ? 8 : 4,
                        childAspectRatio: 1.1,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemCount: selectedZhuotai.length,
                      itemBuilder: (context, index) {
                        final zhuotai = selectedZhuotai[index];
                        return _buildZhuotaiCard(zhuotai);
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}